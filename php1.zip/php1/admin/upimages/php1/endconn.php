﻿<?php
mysql_close();
?>