﻿<?php
	error_reporting(0);
 include("top.php");
?>
<table width="766" height="438" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="229" height="438" align="center" valign="top" bgcolor="#F4F4F4"><?php include("left.php");?>	</td>
    <td width="561" align="center" valign="top" bgcolor="#FFFFFF"><table width="557" height="350" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="557" height="46" background="images/user.gif"><div align="center" style="color: #FFFFFF">会员协议书</div></td>
      </tr>
      <tr>
        <td height="255"><table width="500" height="350" border="0" align="center" cellpadding="0" cellspacing="1">
            <tr>
              <td height="325" bgcolor="#FFFFFF" valign="top">                <DIV style="HEIGHT:325px;WIDTH:500px"> &nbsp;&nbsp;<br>
&nbsp;&nbsp;&nbsp; 用户协议<br>
              <br>
              <table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td height="152" valign="top"><div align="left"> 欢迎您注册为本论坛的用户,作为论坛用户必须要遵守以下协议:<br>
                          <br>
                      1 不得违反国家的法律法规;<br>
                      <br>
                      2 诚实进行商品交易;<br>
                      <br>
                      3 管理员有权删除您的信息,留言等;<br>
                      <br>
                      4 不得发表不文明的言论;<br>
                      <br>
                  </div></td>
                </tr>
              </table>
              </div></td>
            </tr>
            <tr>
              <td height="25" bgcolor="#FFFFFF"><div align="center"><a href="index.php">我不同意</a>&nbsp;&nbsp;<a href="reg.php">我同意</a></div></td>
            </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<?php
 include("bottom.php");
?>