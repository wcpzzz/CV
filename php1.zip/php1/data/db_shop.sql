/*
Navicat MySQL Data Transfer

Source Server         : xampp
Source Server Version : 50611
Source Host           : localhost:3306
Source Database       : db_shop

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2019-01-02 21:50:23
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `tb_admin`
-- ----------------------------
DROP TABLE IF EXISTS `tb_admin`;
CREATE TABLE `tb_admin` (
  `id` int(4) NOT NULL DEFAULT '0',
  `name` varchar(25) DEFAULT NULL,
  `pwd` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_admin
-- ----------------------------
INSERT INTO tb_admin VALUES ('1', 'tsoft', '698d51a19d8a121ce581499d7b701668');

-- ----------------------------
-- Table structure for `tb_dingdan`
-- ----------------------------
DROP TABLE IF EXISTS `tb_dingdan`;
CREATE TABLE `tb_dingdan` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `dingdanhao` varchar(125) DEFAULT NULL,
  `spc` varchar(125) DEFAULT NULL,
  `slc` varchar(125) DEFAULT NULL,
  `shouhuoren` varchar(25) DEFAULT NULL,
  `sex` varchar(2) DEFAULT NULL,
  `dizhi` varchar(125) DEFAULT NULL,
  `youbian` varchar(10) DEFAULT NULL,
  `tel` varchar(25) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `shff` varchar(25) DEFAULT NULL,
  `zfff` varchar(25) DEFAULT NULL,
  `leaveword` mediumtext,
  `time` varchar(25) DEFAULT NULL,
  `xiadanren` varchar(25) DEFAULT NULL,
  `zt` varchar(50) DEFAULT NULL,
  `total` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_dingdan
-- ----------------------------
INSERT INTO tb_dingdan VALUES ('79', '2007111415234939', '211@', '1@', 'dd', '男', 'dd', '130031', '0431-84978***', 'aa@sina.com', '送货上门', '建设银行汇款', 'ddd', '2007-11-14 15:23:49', '纯净水', '已发货&nbsp;', '2599');
INSERT INTO tb_dingdan VALUES ('99', '2007112911451739', '213@', '1@', '纯净水', '女', '黑龙江', '130021', '136********', '130021', '普通平邮', '建设银行汇款', '无', '2007-11-29 11:45:17', '纯净水', '未作任何处理', '9599');
INSERT INTO tb_dingdan VALUES ('98', '2007112911423439', '215@', '1@', '纯净水', '女', '长春市', '130021', '136********', 'tiansi***@sina.com', '普通平邮', '建设银行汇款', '无', '2007-11-29 11:42:34', '纯净水', '未作任何处理', '1399');
INSERT INTO tb_dingdan VALUES ('80', '2007111415332239', '202@', '6@', 'ss', '男', 'ss', '130000', '0431-8497226*', '454@ekek.com', '特快专递', '建设银行汇款', 'ddd', '2007-11-14 15:33:22', '纯净水', '已发货&nbsp;', '588');
INSERT INTO tb_dingdan VALUES ('78', '2007111415170839', '211@202@', '2@1@', '深奥', '男', '长春', '130000', '1365698***', 'chunjingshui**@si*.com', '特快专递', '建设银行汇款', '正在测试中', '2007-11-14 15:17:08', '纯净水', '已发货&nbsp;', '5296');
INSERT INTO tb_dingdan VALUES ('81', '2007111415360839', '202@', '4@', 'll', '男', 'dd', '130000', '0431-8497226*', '454@ekek.com', '普通平邮', '建设银行汇款', 'ddd', '2007-11-14 15:36:08', '纯净水', '已发货&nbsp;', '392');
INSERT INTO tb_dingdan VALUES ('82', '2007111415421739', '202@', '8@', 'dddd', '男', 'dddd', '3333333', '33333', '454@ekek.com', '普通平邮', '建设银行汇款', '333', '2007-11-14 15:42:17', '纯净水', '已发货&nbsp;', '784');
INSERT INTO tb_dingdan VALUES ('83', '2007111415531039', '202@', '1@', 'ddddd', '男', 'dddd', '130000', '0431-8497226*', 'aa@sina.com', '特快专递', '建设银行汇款', 'dfdf', '2007-11-14 15:53:10', '纯净水', '未作任何处理', '98');
INSERT INTO tb_dingdan VALUES ('84', '2007111508514439', '202@', '2@', 'ldsf', '男', 'laksf', 'lksf', 'lk21', 'fjlkd@sina.com', '普通平邮', '建设银行汇款', 'sdf', '2007-11-15 08:51:44', '纯净水', '已收款&nbsp;已发货&nbsp;已收货&nbsp;', '196');
INSERT INTO tb_dingdan VALUES ('85', '2007111915194439', '211@', '2@', 'sss', '男', 'sss', 'ss', 'ssss', '454@ekek.com', '普通平邮', '建设银行汇款', 'dfdf', '2007-11-19 15:19:44', '纯净水', '未作任何处理', '5198');
INSERT INTO tb_dingdan VALUES ('87', '2007112118305339', '211@', '2@', 'sdfdf', '男', 'fsdff', 'sdfsdf', 'sfsfsdfs', '454@ekek.com', '普通平邮', '建设银行汇款', 'dfsdf', '2007-11-21 18:30:53', '纯净水', '已收款&nbsp;已发货&nbsp;已收货&nbsp;', '5198');
INSERT INTO tb_dingdan VALUES ('88', '2007112214363739', '211@', '1@', '紫璇', '女', '吉林省长春市河东路1**号', '130000', '0431-84978***', 'zixuan**@si*.com', '送货上门', '网上支付', '保证质量，轻拿轻放！货到前10分钟打电话通知！', '2007-11-22 14:36:37', '纯净水', '未作任何处理', '2599');
INSERT INTO tb_dingdan VALUES ('97', '2007112911284639', '216@@', '10@@', '纯净水', '女', '长春市', '130021', '136********', 'tiansi***@sina.com', '普通平邮', '建设银行汇款', '急', '2007-11-29 11:28:46', '纯净水', '已收款&nbsp;已发货&nbsp;已收货&nbsp;', '8000');
INSERT INTO tb_dingdan VALUES ('90', '2007112215175939', '211@', '1@', 'ddddd', '女', 'dddd', 'ddd', 'ddd', 'dd@aa.com', '普通平邮', '建设银行汇款', 'ddfsdf', '2007-11-22 15:17:59', '纯净水', '未作任何处理', '2599');
INSERT INTO tb_dingdan VALUES ('91', '2007112215263939', '211@', '1@', '33', '男', '4435', '332', '22', '454@ekek.com', '普通平邮', '建设银行汇款', 'asdf', '2007-11-22 15:26:39', '纯净水', '未作任何处理', '2599');
INSERT INTO tb_dingdan VALUES ('100', '2007112913155042', '213@', '1@', 'lx', '男', '1', '1300211', '10', '12.@lkfj.com', '普通平邮', '建设银行汇款', '1', '2007-11-29 13:15:50', 'lx', '已收款&nbsp;已发货&nbsp;已收货&nbsp;', '9599');
INSERT INTO tb_dingdan VALUES ('95', '2007112813551939', '213@', '1@', 'dfer', '男', 'dfer', 'ererwer', 'rrwerwer', 'rwer**@dins.com', '送货上门', '建设银行汇款', 'ewrwer', '2007-11-28 13:55:19', '纯净水', '未作任何处理', '9599');
INSERT INTO tb_dingdan VALUES ('96', '2007112814155139', '213@', '1@', 'retret', '男', 'dfder', 'erwr', '435', '454***@ekek.com', '送货上门', '建设银行汇款', 'dfr34', '2007-11-28 14:15:51', '纯净水', '未作任何处理', '9599');
INSERT INTO tb_dingdan VALUES ('101', '2007113010324643', '213@', '1@', '张丽', '女', '长春市', '130021', '136********', 'tiansi***@sina.com', '普通平邮', '建设银行汇款', '无', '2007-11-30 10:32:46', 'lx', '未作任何处理', '9599');
INSERT INTO tb_dingdan VALUES ('104', '2018122020082648', '213@', '1@', '666', '男', '666', '50000', '13647683523', '1248654632@qq.com', '普通平邮', '建设银行汇款', '', '2018-12-20 20:08:26', '123456', '未作任何处理', '9599');

-- ----------------------------
-- Table structure for `tb_gonggao`
-- ----------------------------
DROP TABLE IF EXISTS `tb_gonggao`;
CREATE TABLE `tb_gonggao` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `title` varchar(66) DEFAULT NULL,
  `content` text,
  `time` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_gonggao
-- ----------------------------
INSERT INTO tb_gonggao VALUES ('23', '等等', '大大的', '2010-08-16');
INSERT INTO tb_gonggao VALUES ('25', '6666', '6666666', '2018-12-21');

-- ----------------------------
-- Table structure for `tb_leaveword`
-- ----------------------------
DROP TABLE IF EXISTS `tb_leaveword`;
CREATE TABLE `tb_leaveword` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `userid` int(4) DEFAULT NULL,
  `title` varchar(66) DEFAULT NULL,
  `content` text,
  `time` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_leaveword
-- ----------------------------
INSERT INTO tb_leaveword VALUES ('15', '45', '666', '666', '2018-12-20');

-- ----------------------------
-- Table structure for `tb_links`
-- ----------------------------
DROP TABLE IF EXISTS `tb_links`;
CREATE TABLE `tb_links` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `linkname` varchar(50) NOT NULL,
  `linkurl` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_links
-- ----------------------------
INSERT INTO tb_links VALUES ('1', '编程体验网', 'http://www.bcty365.com');
INSERT INTO tb_links VALUES ('2', '编程资源网', 'http://www.bc110.com');
INSERT INTO tb_links VALUES ('3', '编程词典网', 'http://www.mrbccd.com');
INSERT INTO tb_links VALUES ('4', '编程词典网', 'http://www.mrbccd.net');
INSERT INTO tb_links VALUES ('5', '编程体验网', 'http://www.cccxy.com');
INSERT INTO tb_links VALUES ('6', '编程词典网', 'http://www.mrbccd.cn');

-- ----------------------------
-- Table structure for `tb_pingjia`
-- ----------------------------
DROP TABLE IF EXISTS `tb_pingjia`;
CREATE TABLE `tb_pingjia` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `userid` int(4) DEFAULT NULL,
  `spid` int(4) DEFAULT NULL,
  `title` varchar(66) DEFAULT NULL,
  `content` text,
  `time` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_pingjia
-- ----------------------------

-- ----------------------------
-- Table structure for `tb_shangpin`
-- ----------------------------
DROP TABLE IF EXISTS `tb_shangpin`;
CREATE TABLE `tb_shangpin` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `mingcheng` varchar(25) DEFAULT NULL,
  `jianjie` mediumtext,
  `addtime` varchar(25) DEFAULT NULL,
  `dengji` varchar(5) DEFAULT NULL,
  `xinghao` varchar(25) DEFAULT NULL,
  `tupian` varchar(200) DEFAULT NULL,
  `shuliang` int(4) DEFAULT NULL,
  `cishu` int(4) DEFAULT NULL,
  `tuijian` int(4) DEFAULT NULL,
  `typeid` int(4) DEFAULT NULL,
  `huiyuanjia` varchar(25) DEFAULT NULL,
  `shichangjia` varchar(25) DEFAULT NULL,
  `pinpai` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=220 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_shangpin
-- ----------------------------
INSERT INTO tb_shangpin VALUES ('211', '数码相机', '引领时尚的数码科技', '2006-5-5', '精品', 'XM-5001', 'admin/upimages/5.jpg', '20000', '10', '1', '3', '2599', '2699', '时尚');
INSERT INTO tb_shangpin VALUES ('202', '水杯', '好看', '1995-1-1', '精品', '44', 'admin/upimages/1.', '1800', '22', '1', '25', '98', '100', '44');
INSERT INTO tb_shangpin VALUES ('203', '全自动洗衣机', '无', '2005-7-8', '一般', '301X', 'admin/upimages/4.jpg', '8000', '0', '1', '8', '1699', '1800', 'X44');
INSERT INTO tb_shangpin VALUES ('212', '玩具车', '好车，very good', '2002-2-1', '精品', 'Handle-88', 'admin/upimages/3.jpg', '888', '0', '0', '12', '366', '399', 'LOVE-88');
INSERT INTO tb_shangpin VALUES ('213', '家庭影院', '质、精', '2007-1-1', '精品', 'LOVE-99', 'admin/upimages/7.jpg', '98', '1', '1', '3', '9599', '9999', '时尚LOVE');
INSERT INTO tb_shangpin VALUES ('214', '液晶显示器', '经济实用', '2006-1-1', '精品', 'LOVE-999', 'admin/upimages/77.jpg', '99', '0', '1', '3', '2666', '2999', '时尚LOVE');
INSERT INTO tb_shangpin VALUES ('215', '液晶显示器LVOE', '优惠', '2007-1-1', '一般', 'LOVE-2', 'admin/upimages/2.jpg', '88', '0', '0', '3', '1399', '1499', 'LOVE2');
INSERT INTO tb_shangpin VALUES ('216', 'aaaa', '免检产品', '2007-1-1', '一般', 'a', 'admin/upimages/9.jpg', '0', '10', '1', '22', '800', '1000', 'a');

-- ----------------------------
-- Table structure for `tb_type`
-- ----------------------------
DROP TABLE IF EXISTS `tb_type`;
CREATE TABLE `tb_type` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `typename` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_type
-- ----------------------------
INSERT INTO tb_type VALUES ('25', '事实上');
INSERT INTO tb_type VALUES ('23', '所示');
INSERT INTO tb_type VALUES ('24', '等等');

-- ----------------------------
-- Table structure for `tb_user`
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) DEFAULT NULL,
  `pwd` varchar(50) DEFAULT NULL,
  `dongjie` int(4) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `sfzh` varchar(25) DEFAULT NULL,
  `tel` varchar(25) DEFAULT NULL,
  `qq` varchar(25) DEFAULT NULL,
  `tishi` varchar(50) DEFAULT NULL,
  `huida` varchar(50) DEFAULT NULL,
  `dizhi` varchar(100) DEFAULT NULL,
  `youbian` varchar(25) DEFAULT NULL,
  `regtime` varchar(25) DEFAULT NULL,
  `truename` varchar(25) DEFAULT NULL,
  `pwd1` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO tb_user VALUES ('41', '深蓝易思', '96e79218965eb72c92a549dd5a330112', '0', '1248654632@qq.com', '500104200002080020', '12345678911', '', '您最喜欢的花', '百合花', '重庆', '', '2007-11-14', '蒋?怡', '111111');
INSERT INTO tb_user VALUES ('44', 'mr', 'fdb390e945559e74475ed8c8bbb48ca5', '0', '1248654632@qq.com', '500104200002080020', '12345678911', '', '你的爱好', '大大的', '重庆', '', '2010-08-16', '蒋?怡', 'mrsoft');
INSERT INTO tb_user VALUES ('39', '纯净水', 'fdb390e945559e74475ed8c8bbb48ca5', '0', '1248654632@qq.com', '500104200002080020', '12345678911', '', '您最喜欢的花', '百合花', '重庆', '', '2007-10-26', '蒋?怡', 'mrsoft');
INSERT INTO tb_user VALUES ('43', 'lx', '96e79218965eb72c92a549dd5a330112', '0', '1248654632@qq.com', '500104200002080020', '12345678911', '', '您的生日', '不告诉你', '重庆', '', '2007-11-29', '蒋?怡', '111111');
